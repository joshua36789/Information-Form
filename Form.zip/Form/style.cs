@media only screen and (max-width: 600px) {
  div.example {
    display: none;
  }
}

@media only screen and (min-width: 768px) {
  body {
    display: none;
  }
}

@media only screen and (min-width: 992px) {
  body {
    display: none;
  }
}